import Navigation from "@/components/Navigation";
import Hero from "@/components/Hero";
import About from "@/components/About";
import EssayPrize from "@/components/EssayPrize";
import LiveStatus from "@/components/LiveStatus";
import Courses from "@/components/Courses";
import Faculty from "@/components/Faculty";
import GlobalReach from "@/components/GlobalReach";
import CallToAction from "@/components/CallToAction";
import Newsletter from "@/components/Newsletter";
import Footer from "@/components/Footer";
import SearchPalette from "@/components/Search";

export default function Home() {
  return (
    <>
      <Navigation />
      <SearchPalette />
      <main>
        <Hero />
        <div className="section-divider" />
        <About />
        <div className="section-divider" />
        <LiveStatus />
        <div className="section-divider" />
        <EssayPrize />
        <div className="section-divider" />
        <Courses />
        <div className="section-divider" />
        <Faculty />
        <div className="section-divider" />
        <GlobalReach />
        <div className="section-divider" />
        <CallToAction />
        <div className="section-divider" />
        <Newsletter />
      </main>
      <Footer />
    </>
  );
}