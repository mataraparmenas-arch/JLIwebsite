import { NextResponse } from "next/server";

// Competition events with real dates from the Institute
const competitionEvents = [
  {
    id: 1,
    title: "Registration Opens",
    date: "2026-02-02T23:59:00Z",
    category: "competition",
    status: "complete",
    description: "Registration for the 2026 Global Essay Prize opens",
  },
  {
    id: 2,
    title: "Registration Deadline",
    date: "2026-03-31T23:59:00Z",
    category: "competition",
    status: "complete",
    description: "Registration is required by this date for subsequent submission",
  },
  {
    id: 3,
    title: "Submissions Open",
    date: "2026-04-01T23:59:00Z",
    category: "competition",
    status: "complete",
    description: "Essay submissions open for registered contestants",
  },
  {
    id: 4,
    title: "Late Registration Deadline ($10)",
    date: "2026-04-30T23:59:00Z",
    category: "competition",
    status: "complete",
    description: "Late registration deadline with fee",
  },
  {
    id: 5,
    title: "Submission Deadline",
    date: "2026-05-31T23:59:00Z",
    category: "competition",
    status: "complete",
    description: "Regular essay submission deadline",
  },
  {
    id: 6,
    title: "Late Entry Deadline (7-day)",
    date: "2026-06-07T23:59:00Z",
    category: "competition",
    status: "complete",
    description: "Seven-day extension deadline (£25)",
  },
  {
    id: 7,
    title: "Late Entry Deadline (21-day)",
    date: "2026-06-21T23:59:00Z",
    category: "competition",
    status: "complete",
    description: "Twenty-one-day extension deadline (£75)",
  },
  {
    id: 8,
    title: "Shortlist Notification",
    date: "2026-07-07T23:59:00Z",
    category: "competition",
    status: "active",
    description: "Notification of short-listed essayists",
  },
  {
    id: 9,
    title: "Academic Conference",
    date: "2026-10-02T09:00:00Z",
    endDate: "2026-10-04T17:00:00Z",
    category: "conference",
    status: "upcoming",
    location: "London",
    description: "Invitation-only academic conference in London",
  },
  {
    id: 10,
    title: "Awards Dinner",
    date: "2026-10-03T19:00:00Z",
    category: "ceremony",
    status: "upcoming",
    location: "London",
    description: "Prize-giving ceremony and awards dinner",
  },
  {
    id: 11,
    title: "Summer School — Singapore",
    date: "2026-06-15T09:00:00Z",
    category: "course",
    status: "complete",
    location: "Singapore",
    description: "Summer school programme in Singapore",
  },
  {
    id: 12,
    title: "Summer School — Georgetown",
    date: "2026-06-22T09:00:00Z",
    category: "course",
    status: "complete",
    location: "Georgetown, Washington D.C.",
    description: "Summer school programme at Georgetown",
  },
  {
    id: 13,
    title: "Summer School — Cambridge",
    date: "2026-07-06T09:00:00Z",
    category: "course",
    status: "upcoming",
    location: "Cambridge, UK",
    description: "Summer school programme in Cambridge",
  },
  {
    id: 14,
    title: "Summer School — Princeton",
    date: "2026-07-13T09:00:00Z",
    category: "course",
    status: "upcoming",
    location: "Princeton, NJ",
    description: "Summer school programme at Princeton",
  },
  {
    id: 15,
    title: "Summer School — Oxford",
    date: "2026-07-20T09:00:00Z",
    category: "course",
    status: "upcoming",
    location: "Oxford, UK",
    description: "Summer school programme in Oxford",
  },
];

export async function GET() {
  return NextResponse.json({
    events: competitionEvents,
    nextEvent: competitionEvents.find(
      (e) => new Date(e.date) > new Date() && e.status !== "complete"
    ),
    liveStatus: {
      current: "Shortlist Review Period",
      description:
        "The judges are reviewing submissions. Shortlisted essayists will be notified by 7 July 2026.",
      isActive: true,
    },
  });
}