import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "John Locke Institute — The Future of Intellectual Education",
  description:
    "A growing community of professors, students and alumni, encouraging each other to listen generously, think critically, and argue persuasively. Summer schools, essay competitions, and academic programmes worldwide.",
  keywords: [
    "John Locke Institute",
    "essay competition",
    "philosophy",
    "politics",
    "economics",
    "summer school",
    "Oxford",
    "academic",
  ],
  icons: {
    icon: "/favicon.svg",
  },
  openGraph: {
    title: "John Locke Institute — The Future of Intellectual Education",
    description:
      "Nurturing the intellectual humility and the courage to think differently.",
    type: "website",
    siteName: "John Locke Institute",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              (function() {
                try {
                  var theme = localStorage.getItem('theme');
                  if (!theme) theme = 'dark';
                  document.documentElement.setAttribute('data-theme', theme);
                } catch(e) {}
              })();
            `,
          }}
        />
      </head>
      <body
        className="antialiased"
        style={{
          fontFamily:
            "'Inter', system-ui, -apple-system, BlinkMacSystemFont, sans-serif",
          background: "var(--bg-primary)",
          color: "var(--text-primary)",
        }}
      >
        {children}
      </body>
    </html>
  );
}