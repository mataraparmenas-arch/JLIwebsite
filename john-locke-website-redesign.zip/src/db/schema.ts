import { pgTable, text, timestamp, integer, boolean, jsonb } from "drizzle-orm/pg-core";

export const events = pgTable("events", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  title: text("title").notNull(),
  description: text("description"),
  date: timestamp("date", { withTimezone: true }).notNull(),
  endDate: timestamp("end_date", { withTimezone: true }),
  category: text("category").notNull().default("general"),
  location: text("location"),
  isLive: boolean("is_live").default(false),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
});

export const competitionDates = pgTable("competition_dates", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  year: integer("year").notNull(),
  milestone: text("milestone").notNull(),
  date: timestamp("date", { withTimezone: true }).notNull(),
  description: text("description"),
  isActive: boolean("is_active").default(true),
});

export const courses = pgTable("courses", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  name: text("name").notNull(),
  location: text("location").notNull(),
  country: text("country").notNull(),
  description: text("description"),
  ageRange: text("age_range"),
  startDate: timestamp("start_date", { withTimezone: true }),
  endDate: timestamp("end_date", { withTimezone: true }),
  isOpen: boolean("is_open").default(true),
  imageUrl: text("image_url"),
  coordinates: jsonb("coordinates"),
});

export const faculty = pgTable("faculty", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  name: text("name").notNull(),
  title: text("title").notNull(),
  institution: text("institution").notNull(),
  bio: text("bio"),
  imageUrl: text("image_url"),
  category: text("category"),
  sortOrder: integer("sort_order").default(0),
});

export const statistics = pgTable("statistics", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  label: text("label").notNull(),
  value: integer("value").notNull(),
  suffix: text("suffix").default("+"),
  category: text("category"),
});

export const newsletter = pgTable("newsletter", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  email: text("email").notNull().unique(),
  name: text("name"),
  subscribedAt: timestamp("subscribed_at", { withTimezone: true }).defaultNow(),
});