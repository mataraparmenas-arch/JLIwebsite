"use client";

import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { Mail, Phone, MapPin, ArrowUp } from "lucide-react";

const footerLinks = {
  Programmes: [
    { label: "Summer Schools", href: "#courses" },
    { label: "Gap Year", href: "#courses" },
    { label: "Admissions", href: "#courses" },
  ],
  Competition: [
    { label: "Global Essay Prize", href: "#essay-prize" },
    { label: "Key Dates", href: "#essay-prize" },
    { label: "FAQs", href: "#essay-prize" },
  ],
  Locations: [
    { label: "Oxford", href: "#courses" },
    { label: "Cambridge", href: "#courses" },
    { label: "Princeton", href: "#courses" },
    { label: "Singapore", href: "#courses" },
    { label: "Dubai", href: "#courses" },
    { label: "Hong Kong", href: "#courses" },
  ],
  Institute: [
    { label: "About", href: "#about" },
    { label: "Faculty", href: "#faculty" },
    { label: "Contact", href: "#contact" },
  ],
};

export default function Footer() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer
      id="contact"
      ref={ref}
      className="relative pt-24 pb-8 overflow-hidden"
      style={{ background: "var(--bg-secondary)" }}
    >
      {/* Top decorative line */}
      <div className="section-divider mb-24" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Large Title */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          className="mb-16"
        >
          <h2
            className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold leading-[0.95] mb-6"
            style={{ fontFamily: "var(--font-serif)" }}
          >
            <span style={{ color: "var(--text-primary)" }}>JOHN LOCKE</span>
            <br />
            <span className="text-gradient-blue">INSTITUTE</span>
          </h2>
          <p
            className="text-base md:text-lg max-w-xl"
            style={{ color: "var(--text-secondary)" }}
          >
            Nurturing the intellectual humility and the courage to think
            differently.
          </p>
        </motion.div>

        {/* Link Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-16"
        >
          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category}>
              <h4
                className="text-xs tracking-[0.2em] uppercase font-semibold mb-4"
                style={{ color: "var(--text-primary)" }}
              >
                {category}
              </h4>
              <ul className="space-y-3">
                {links.map((link) => (
                  <li key={link.label}>
                    <a
                      href={link.href}
                      onClick={(e) => {
                        e.preventDefault();
                        const el = document.querySelector(link.href);
                        if (el)
                          el.scrollIntoView({
                            behavior: "smooth",
                            block: "start",
                          });
                      }}
                      className="text-sm hover:opacity-100 transition-opacity"
                      style={{
                        color: "var(--text-secondary)",
                        opacity: 0.6,
                      }}
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </motion.div>

        {/* Contact */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.3 }}
          className="glass rounded-xl p-6 md:p-8 mb-16"
        >
          <h4
            className="text-sm tracking-wider uppercase font-semibold mb-6"
            style={{ color: "var(--text-primary)" }}
          >
            Contact Us
          </h4>
          <div className="grid sm:grid-cols-3 gap-6">
            <a
              href="mailto:admissions@johnlocke.com"
              className="flex items-center gap-3 group"
            >
              <div className="w-10 h-10 rounded-lg flex items-center justify-center bg-blue-500/10 group-hover:bg-blue-500/20 transition-colors">
                <Mail className="w-4 h-4 text-blue-400" />
              </div>
              <div>
                <div
                  className="text-xs mb-0.5"
                  style={{ color: "var(--text-secondary)", opacity: 0.5 }}
                >
                  Email
                </div>
                <div
                  className="text-sm"
                  style={{ color: "var(--text-primary)" }}
                >
                  admissions@johnlocke.com
                </div>
              </div>
            </a>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg flex items-center justify-center bg-violet-500/10">
                <Phone className="w-4 h-4 text-violet-400" />
              </div>
              <div>
                <div
                  className="text-xs mb-0.5"
                  style={{ color: "var(--text-secondary)", opacity: 0.5 }}
                >
                  Princeton
                </div>
                <div
                  className="text-sm"
                  style={{ color: "var(--text-primary)" }}
                >
                  +1 (609) 608-0543
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg flex items-center justify-center bg-amber-500/10">
                <MapPin className="w-4 h-4 text-amber-400" />
              </div>
              <div>
                <div
                  className="text-xs mb-0.5"
                  style={{ color: "var(--text-secondary)", opacity: 0.5 }}
                >
                  Oxford
                </div>
                <div
                  className="text-sm"
                  style={{ color: "var(--text-primary)" }}
                >
                  +44 (0)1865 566166
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Bottom bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-8 border-t border-white/5">
          <p
            className="text-xs"
            style={{ color: "var(--text-secondary)", opacity: 0.4 }}
          >
            © {new Date().getFullYear()} John Locke Institute. All rights
            reserved.
          </p>

          <div className="flex items-center gap-6">
            <a
              href="https://www.johnlockeinstitute.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs hover:opacity-100 transition-opacity"
              style={{
                color: "var(--text-secondary)",
                opacity: 0.4,
              }}
            >
              johnlockeinstitute.com
            </a>

            <button
              onClick={scrollToTop}
              className="w-9 h-9 rounded-full flex items-center justify-center hover:bg-white/5 transition-colors group"
              style={{ border: "1px solid rgba(255,255,255,0.06)" }}
              aria-label="Back to top"
            >
              <ArrowUp
                className="w-4 h-4 group-hover:-translate-y-0.5 transition-transform"
                style={{ color: "var(--text-secondary)" }}
              />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}