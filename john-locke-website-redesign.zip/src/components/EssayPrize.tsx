"use client";

import { useState, useEffect, useRef } from "react";
import { motion, useInView, AnimatePresence } from "framer-motion";
import {
  Clock,
  Trophy,
  ChevronRight,
  FileText,
  Calendar,
  Award,
  X,
} from "lucide-react";

const categories = [
  {
    name: "Economics",
    icon: "📊",
    color: "#10b981",
    questions: [
      "Should we fear a cashless society?",
      "Technology now allows personalised pricing. If this came to be widely used, what effects should we expect?",
      "Did Jeff Bezos get rich at the expense of his customers, his employees, neither or both?",
    ],
  },
  {
    name: "History",
    icon: "📜",
    color: "#f59e0b",
    questions: [
      "'The arc of the moral universe is long, but it bends toward justice.' Is it? Does it?",
      "What might the world look like if the Library of Alexandria hadn't burned down?",
      "Does Che deserve his iconic T-shirt?",
    ],
  },
  {
    name: "International Relations",
    icon: "🌍",
    color: "#3b82f6",
    questions: [
      "Does foreign aid help or hurt poor people?",
      "Is the US economy harmed by cheap imports from China?",
      "Should a coalition of countries (or of billionaires) run an experiment with a libertarian microstate?",
    ],
  },
  {
    name: "Law",
    icon: "⚖️",
    color: "#8b5cf6",
    questions: [
      "If legislators and judges all accepted the philosophical theory of determinism, what would be the effect on criminal sentencing?",
      "To what extent should criminal sentencing take into account the effect on the perpetrator's family?",
      "Is trial by jury obsolete?",
    ],
  },
  {
    name: "Philosophy",
    icon: "🏛️",
    color: "#ec4899",
    questions: [
      "Is it ever wrong to do the right thing for the wrong reasons?",
      "What consolations does philosophy offer?",
      "Why is incest wrong?",
    ],
  },
  {
    name: "Politics",
    icon: "🏛️",
    color: "#ef4444",
    questions: [
      "Is the right to self-determination absolute?",
      "Did the pandemic normalise authoritarianism?",
      "Is democracy in crisis?",
    ],
  },
  {
    name: "Psychology",
    icon: "🧠",
    color: "#06b6d4",
    questions: [
      "Why do we care what happens to our body after death?",
      "Is mental illness over-diagnosed now, or just better recognised?",
      "Surveys show a widening gender ideological gap in recent years. Why?",
    ],
  },
  {
    name: "Public Policy",
    icon: "📋",
    color: "#14b8a6",
    questions: [
      "What discount rate should be applied to long-run environmental policies? Why?",
      "Which unintended consequence was most devastating and why did we fail to predict it?",
      "Should vaccination be mandatory in a public health emergency?",
    ],
  },
  {
    name: "Science & Technology",
    icon: "🔬",
    color: "#a855f7",
    questions: [
      "Is free speech the enemy of science?",
      "Is space exploration a necessity or an indulgence?",
      "Should we be polite to ChatGPT?",
    ],
  },
  {
    name: "Theology",
    icon: "✡️",
    color: "#d4a853",
    questions: [
      "Is religious experience better explained by neuroscience or by theology?",
      "Research shows a strong inverse correlation between religiosity and per-capita spending on education. Does one cause the other?",
      "If you achieve enlightenment, how will you know?",
    ],
  },
];

const milestones = [
  { label: "Registration Opens", date: "2 Feb 2026", status: "complete" },
  { label: "Registration Deadline", date: "31 Mar 2026", status: "complete" },
  { label: "Submissions Open", date: "1 Apr 2026", status: "complete" },
  { label: "Submission Deadline", date: "31 May 2026", status: "complete" },
  { label: "Shortlist Notification", date: "7 Jul 2026", status: "active" },
  { label: "Academic Conference", date: "2–4 Oct 2026", status: "upcoming" },
  { label: "Awards Dinner", date: "3 Oct 2026", status: "upcoming" },
];

function useCountdown(targetDate: Date) {
  const [time, setTime] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 });

  useEffect(() => {
    const tick = () => {
      const now = new Date().getTime();
      const diff = targetDate.getTime() - now;
      if (diff <= 0) {
        setTime({ days: 0, hours: 0, minutes: 0, seconds: 0 });
        return;
      }
      setTime({
        days: Math.floor(diff / (1000 * 60 * 60 * 24)),
        hours: Math.floor((diff / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((diff / (1000 * 60)) % 60),
        seconds: Math.floor((diff / 1000) % 60),
      });
    };
    tick();
    const interval = setInterval(tick, 1000);
    return () => clearInterval(interval);
  }, [targetDate]);

  return time;
}

export default function EssayPrize() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);

  // Countdown to Academic Conference: 2 October 2026
  const conferenceDate = new Date("2026-10-02T00:00:00Z");
  const countdown = useCountdown(conferenceDate);

  return (
    <section
      id="essay-prize"
      ref={ref}
      className="relative py-24 md:py-32 overflow-hidden"
    >
      {/* Background accents */}
      <div className="absolute inset-0">
        <div
          className="absolute top-0 left-1/4 w-96 h-96 rounded-full"
          style={{
            background:
              "radial-gradient(circle, rgba(139, 92, 246, 0.06) 0%, transparent 70%)",
          }}
        />
        <div
          className="absolute bottom-0 right-1/4 w-96 h-96 rounded-full"
          style={{
            background:
              "radial-gradient(circle, rgba(59, 130, 246, 0.04) 0%, transparent 70%)",
          }}
        />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Label */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          className="mb-4"
        >
          <span
            className="text-xs tracking-[0.3em] uppercase font-medium"
            style={{ color: "var(--accent-tertiary)" }}
          >
            Global Essay Prize 2026
          </span>
        </motion.div>

        {/* Heading */}
        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.1 }}
          className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-4"
          style={{ fontFamily: "var(--font-serif)" }}
        >
          The World&apos;s Most
          <br />
          <span className="text-gradient-gold">Prestigious Essay</span>{" "}
          Competition
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.2 }}
          className="max-w-3xl text-base md:text-lg leading-relaxed mb-12"
          style={{ color: "var(--text-secondary)" }}
        >
          The John Locke Institute encourages young people to cultivate the
          characteristics that turn good students into great writers: independent
          thought, depth of knowledge, clear reasoning, critical analysis and
          persuasive style.
        </motion.p>

        {/* Status Badge */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={isInView ? { opacity: 1, scale: 1 } : {}}
          transition={{ delay: 0.3 }}
          className="inline-flex items-center gap-3 px-5 py-3 rounded-full glass mb-12"
        >
          <span className="relative flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75" />
            <span className="relative inline-flex rounded-full h-3 w-3 bg-amber-500" />
          </span>
          <span
            className="text-sm font-medium"
            style={{ color: "var(--text-primary)" }}
          >
            Registration closed — Submissions complete — Awaiting shortlist
          </span>
        </motion.div>

        {/* Countdown */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.4 }}
          className="glass rounded-2xl p-8 md:p-12 mb-16"
        >
          <div className="flex items-center gap-3 mb-8">
            <Clock className="w-5 h-5" style={{ color: "var(--accent-primary)" }} />
            <span
              className="text-sm tracking-widest uppercase"
              style={{ color: "var(--accent-primary)" }}
            >
              Countdown to Academic Conference
            </span>
          </div>

          <div className="grid grid-cols-4 gap-4 md:gap-8 max-w-2xl">
            {[
              { value: countdown.days, label: "Days" },
              { value: countdown.hours, label: "Hours" },
              { value: countdown.minutes, label: "Minutes" },
              { value: countdown.seconds, label: "Seconds" },
            ].map((item) => (
              <div key={item.label} className="text-center">
                <div className="countdown-digit">
                  {String(item.value).padStart(2, "0")}
                </div>
                <div
                  className="text-xs tracking-widest uppercase mt-2"
                  style={{ color: "var(--text-secondary)", opacity: 0.6 }}
                >
                  {item.label}
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Timeline */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.5 }}
          className="mb-16"
        >
          <h3
            className="text-xl md:text-2xl font-bold mb-8 flex items-center gap-3"
            style={{ fontFamily: "var(--font-serif)" }}
          >
            <Calendar
              className="w-5 h-5"
              style={{ color: "var(--accent-primary)" }}
            />
            Competition Timeline
          </h3>

          <div className="relative">
            {/* Timeline line */}
            <div
              className="absolute left-4 md:left-1/2 top-0 bottom-0 w-px"
              style={{ background: "rgba(255,255,255,0.06)" }}
            />

            <div className="space-y-6">
              {milestones.map((m, i) => (
                <motion.div
                  key={m.label}
                  initial={{ opacity: 0, x: i % 2 === 0 ? -20 : 20 }}
                  animate={isInView ? { opacity: 1, x: 0 } : {}}
                  transition={{ delay: 0.5 + i * 0.08 }}
                  className={`relative flex items-center gap-4 md:gap-0 ${
                    i % 2 === 0
                      ? "md:flex-row"
                      : "md:flex-row-reverse"
                  } pl-12 md:pl-0`}
                >
                  {/* Content */}
                  <div
                    className={`flex-1 ${
                      i % 2 === 0 ? "md:text-right md:pr-8" : "md:text-left md:pl-8"
                    }`}
                  >
                    <div
                      className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs ${
                        m.status === "complete"
                          ? "bg-emerald-500/10 text-emerald-400"
                          : m.status === "active"
                          ? "bg-amber-500/10 text-amber-400"
                          : "bg-white/5"
                      }`}
                      style={
                        m.status === "upcoming"
                          ? { color: "var(--text-secondary)" }
                          : {}
                      }
                    >
                      {m.status === "complete" && "✓"}
                      {m.status === "active" && (
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" />
                      )}
                      {m.date}
                    </div>
                    <div
                      className="text-sm font-medium mt-1"
                      style={{ color: "var(--text-primary)" }}
                    >
                      {m.label}
                    </div>
                  </div>

                  {/* Node */}
                  <div
                    className={`absolute left-2.5 md:left-1/2 md:-translate-x-1/2 w-4 h-4 rounded-full border-2 ${
                      m.status === "complete"
                        ? "border-emerald-400 bg-emerald-400/20"
                        : m.status === "active"
                        ? "border-amber-400 bg-amber-400/20"
                        : "border-white/10 bg-white/5"
                    }`}
                  />

                  {/* Spacer for other side */}
                  <div className="hidden md:block flex-1" />
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Prizes */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.6 }}
          className="grid sm:grid-cols-3 gap-6 mb-16"
        >
          {[
            {
              place: "1st Prize",
              amount: "$5,000",
              desc: "Scholarship per category",
              icon: Trophy,
              gradient: "from-amber-500/20 to-yellow-500/10",
              borderColor: "rgba(245, 158, 11, 0.3)",
            },
            {
              place: "2nd Prize",
              amount: "$2,000",
              desc: "Scholarship per category",
              icon: Award,
              gradient: "from-slate-400/20 to-slate-300/10",
              borderColor: "rgba(148, 163, 184, 0.3)",
            },
            {
              place: "Grand Prize",
              amount: "$10,000",
              desc: "Plus Honorary Junior Fellowship",
              icon: Trophy,
              gradient: "from-violet-500/20 to-blue-500/10",
              borderColor: "rgba(139, 92, 246, 0.3)",
            },
          ].map((prize) => (
            <div
              key={prize.place}
              className={`card-premium rounded-xl p-6 bg-gradient-to-br ${prize.gradient}`}
              style={{ border: `1px solid ${prize.borderColor}` }}
            >
              <prize.icon
                className="w-8 h-8 mb-4"
                style={{ color: "var(--accent-tertiary)" }}
              />
              <div
                className="text-sm font-medium mb-1"
                style={{ color: "var(--text-secondary)" }}
              >
                {prize.place}
              </div>
              <div
                className="text-3xl md:text-4xl font-bold mb-2"
                style={{
                  fontFamily: "var(--font-serif)",
                  color: "var(--text-primary)",
                }}
              >
                {prize.amount}
              </div>
              <div
                className="text-xs"
                style={{ color: "var(--text-secondary)", opacity: 0.7 }}
              >
                {prize.desc}
              </div>
            </div>
          ))}
        </motion.div>

        {/* Categories */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.7 }}
        >
          <h3
            className="text-xl md:text-2xl font-bold mb-8 flex items-center gap-3"
            style={{ fontFamily: "var(--font-serif)" }}
          >
            <FileText
              className="w-5 h-5"
              style={{ color: "var(--accent-secondary)" }}
            />
            Subject Categories
          </h3>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3 md:gap-4">
            {categories.map((cat, i) => (
              <motion.button
                key={cat.name}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ delay: 0.7 + i * 0.05 }}
                onClick={() =>
                  setSelectedCategory(
                    selectedCategory === i ? null : i
                  )
                }
                className="card-premium glass rounded-xl p-4 text-left group cursor-pointer"
              >
                <span className="text-2xl mb-3 block">{cat.icon}</span>
                <span
                  className="text-sm font-semibold block mb-1"
                  style={{ color: "var(--text-primary)" }}
                >
                  {cat.name}
                </span>
                <span
                  className="text-xs flex items-center gap-1 group-hover:gap-2 transition-all"
                  style={{ color: cat.color }}
                >
                  3 Questions <ChevronRight className="w-3 h-3" />
                </span>
              </motion.button>
            ))}
          </div>

          {/* Expanded Questions */}
          <AnimatePresence>
            {selectedCategory !== null && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="overflow-hidden"
              >
                <div className="glass rounded-2xl p-6 md:p-8 mt-6">
                  <div className="flex items-center justify-between mb-6">
                    <h4
                      className="text-lg md:text-xl font-bold"
                      style={{
                        fontFamily: "var(--font-serif)",
                        color: "var(--text-primary)",
                      }}
                    >
                      {categories[selectedCategory].icon}{" "}
                      {categories[selectedCategory].name}
                    </h4>
                    <button
                      onClick={() => setSelectedCategory(null)}
                      className="w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/5 transition-colors"
                      style={{ color: "var(--text-secondary)" }}
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="space-y-4">
                    {categories[selectedCategory].questions.map((q, qi) => (
                      <div
                        key={qi}
                        className="flex gap-4 p-4 rounded-lg hover:bg-white/[0.02] transition-colors"
                      >
                        <span
                          className="text-xs font-bold mt-1 shrink-0"
                          style={{ color: categories[selectedCategory].color }}
                        >
                          Q{qi + 1}
                        </span>
                        <p
                          className="text-sm md:text-base leading-relaxed"
                          style={{ color: "var(--text-secondary)" }}
                        >
                          {q}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        {/* Chairman Quote */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.9 }}
          className="mt-16 glass rounded-2xl p-8 md:p-12"
        >
          <div className="flex items-center gap-2 mb-6">
            <Award
              className="w-5 h-5"
              style={{ color: "var(--accent-tertiary)" }}
            />
            <span
              className="text-xs tracking-widest uppercase"
              style={{ color: "var(--accent-tertiary)" }}
            >
              From the Chairman of Examiners
            </span>
          </div>
          <blockquote
            className="text-lg md:text-xl leading-relaxed mb-6 italic"
            style={{
              fontFamily: "var(--font-serif)",
              color: "var(--text-primary)",
            }}
          >
            &ldquo;The John Locke Institute&apos;s Global Essay Prize is
            acknowledged as the world&apos;s most prestigious essay competition.
            We welcome tens of thousands of submissions from ambitious students
            in more than 150 countries.&rdquo;
          </blockquote>
          <div
            className="text-sm"
            style={{ color: "var(--text-secondary)" }}
          >
            <strong>Professor Terence Kealey, D.Phil. (Oxon)</strong>
            <br />
            Chairman of Examiners
          </div>
        </motion.div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ delay: 1 }}
          className="mt-12 text-center"
        >
          <a
            href="https://www.johnlockeinstitute.com/essay-competition"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-gold"
          >
            <span>View Full Competition Details</span>
            <ChevronRight className="w-4 h-4" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}