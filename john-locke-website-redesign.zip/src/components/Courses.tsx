"use client";

import { useRef, useState } from "react";
import { motion, useInView } from "framer-motion";
import { MapPin, ArrowRight, Calendar, Users } from "lucide-react";

const locations = [
  {
    name: "Oxford",
    country: "United Kingdom",
    description:
      "Study in the historic home of the John Locke Institute, surrounded by centuries of academic tradition.",
    coordinates: { lat: 51.7548, lng: -1.2544 },
    gradient: "from-blue-600/20 to-indigo-600/10",
  },
  {
    name: "Cambridge",
    country: "United Kingdom",
    description:
      "Experience university-level courses in one of the world's most renowned academic cities.",
    coordinates: { lat: 52.2053, lng: 0.1218 },
    gradient: "from-violet-600/20 to-purple-600/10",
  },
  {
    name: "Princeton",
    country: "United States",
    description:
      "Engage with world-class faculty in the intellectual heart of the American East Coast.",
    coordinates: { lat: 40.3431, lng: -74.6551 },
    gradient: "from-orange-600/20 to-red-600/10",
  },
  {
    name: "Georgetown",
    country: "United States",
    description:
      "Study in Washington D.C., at the intersection of policy, law, and international affairs.",
    coordinates: { lat: 38.9077, lng: -77.0723 },
    gradient: "from-emerald-600/20 to-teal-600/10",
  },
  {
    name: "Boston",
    country: "United States",
    description:
      "Immerse yourself in academic life in one of America's most historic and intellectual cities.",
    coordinates: { lat: 42.3601, lng: -71.0589 },
    gradient: "from-cyan-600/20 to-blue-600/10",
  },
  {
    name: "Singapore",
    country: "Singapore",
    description:
      "Connect with ambitious students across Asia in this vibrant global hub of innovation.",
    coordinates: { lat: 1.3521, lng: 103.8198 },
    gradient: "from-pink-600/20 to-rose-600/10",
  },
  {
    name: "Hong Kong",
    country: "China",
    description:
      "Experience East-meets-West academic culture in one of Asia's most dynamic cities.",
    coordinates: { lat: 22.3193, lng: 114.1694 },
    gradient: "from-amber-600/20 to-yellow-600/10",
  },
  {
    name: "Dubai",
    country: "United Arab Emirates",
    description:
      "Study in the Middle East's most cosmopolitan city, a crossroads of global cultures.",
    coordinates: { lat: 25.2048, lng: 55.2708 },
    gradient: "from-fuchsia-600/20 to-violet-600/10",
  },
  {
    name: "Washington D.C.",
    country: "United States",
    description:
      "Explore policy and governance in the capital of the United States.",
    coordinates: { lat: 38.9072, lng: -77.0369 },
    gradient: "from-sky-600/20 to-blue-600/10",
  },
];

export default function Courses() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [hoveredLocation, setHoveredLocation] = useState<number | null>(null);

  return (
    <section
      id="courses"
      ref={ref}
      className="relative py-24 md:py-32 overflow-hidden"
    >
      <div className="absolute inset-0 gradient-mesh" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Label */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          className="mb-4"
        >
          <span
            className="text-xs tracking-[0.3em] uppercase font-medium"
            style={{ color: "var(--accent-primary)" }}
          >
            Summer Schools & Programmes
          </span>
        </motion.div>

        {/* Heading */}
        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.1 }}
          className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-4"
          style={{ fontFamily: "var(--font-serif)" }}
        >
          Study at the World&apos;s
          <br />
          <span className="text-gradient-blue">Greatest Institutions</span>
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.2 }}
          className="max-w-3xl text-base md:text-lg leading-relaxed mb-6"
          style={{ color: "var(--text-secondary)" }}
        >
          Our summer schools introduce students aged 12–19 to university-level
          courses in philosophy, politics, economics, history, law, and related
          subjects. Designed to reflect the rigour of leading undergraduate
          programmes, they offer an exceptional opportunity to experience
          university life abroad.
        </motion.p>

        {/* Status */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ delay: 0.3 }}
          className="glass inline-flex items-center gap-3 px-4 py-2 rounded-full text-sm mb-12"
          style={{ color: "var(--text-secondary)" }}
        >
          <Calendar className="w-4 h-4" style={{ color: "var(--accent-tertiary)" }} />
          <span>
            2026 Courses — Extended deadline:{" "}
            <strong style={{ color: "var(--text-primary)" }}>
              Sunday, 31 May
            </strong>{" "}
            (Cambridge, Princeton, Oxford)
          </span>
        </motion.div>

        {/* Location Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 mb-16">
          {locations.map((loc, i) => (
            <motion.div
              key={loc.name}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.3 + i * 0.06 }}
              onMouseEnter={() => setHoveredLocation(i)}
              onMouseLeave={() => setHoveredLocation(null)}
              className="card-premium glass rounded-xl overflow-hidden group cursor-pointer"
            >
              {/* Image placeholder with gradient */}
              <div
                className={`relative h-40 bg-gradient-to-br ${loc.gradient} overflow-hidden`}
              >
                {/* Decorative pattern */}
                <div className="absolute inset-0 opacity-10">
                  <svg
                    className="w-full h-full"
                    viewBox="0 0 400 200"
                    fill="none"
                  >
                    <circle
                      cx="350"
                      cy="50"
                      r="100"
                      stroke="currentColor"
                      strokeWidth="0.5"
                      opacity="0.3"
                    />
                    <circle
                      cx="50"
                      cy="180"
                      r="80"
                      stroke="currentColor"
                      strokeWidth="0.5"
                      opacity="0.2"
                    />
                    <line
                      x1="0"
                      y1="100"
                      x2="400"
                      y2="100"
                      stroke="currentColor"
                      strokeWidth="0.3"
                      opacity="0.1"
                    />
                  </svg>
                </div>

                {/* Map Pin */}
                <div className="absolute top-4 left-4 flex items-center gap-2">
                  <div
                    className="w-8 h-8 rounded-full flex items-center justify-center"
                    style={{ background: "rgba(0,0,0,0.3)" }}
                  >
                    <MapPin className="w-4 h-4 text-white" />
                  </div>
                </div>

                {/* Location Name */}
                <div className="absolute bottom-4 left-4">
                  <h3
                    className="text-xl md:text-2xl font-bold text-white transition-transform duration-300 group-hover:translate-x-1"
                    style={{ fontFamily: "var(--font-serif)" }}
                  >
                    {loc.name}
                  </h3>
                  <span className="text-xs text-white/60 tracking-wider uppercase">
                    {loc.country}
                  </span>
                </div>

                {/* Hover overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </div>

              {/* Content */}
              <div className="p-5">
                <p
                  className="text-sm leading-relaxed mb-4"
                  style={{ color: "var(--text-secondary)" }}
                >
                  {loc.description}
                </p>
                <div className="flex items-center justify-between">
                  <span
                    className="text-xs flex items-center gap-1"
                    style={{ color: "var(--text-secondary)", opacity: 0.6 }}
                  >
                    <Users className="w-3 h-3" />
                    Ages 12–19
                  </span>
                  <span
                    className="text-xs flex items-center gap-1 group-hover:gap-2 transition-all"
                    style={{ color: "var(--accent-primary)" }}
                  >
                    Learn more <ArrowRight className="w-3 h-3" />
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Admissions Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.8 }}
          className="glass rounded-2xl p-8 md:p-12"
        >
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h3
                className="text-2xl md:text-3xl font-bold mb-4"
                style={{ fontFamily: "var(--font-serif)" }}
              >
                Admissions
              </h3>
              <p
                className="text-base leading-relaxed mb-4"
                style={{ color: "var(--text-secondary)" }}
              >
                We welcome applications from motivated, high-ability students
                who would benefit from a demanding curriculum, rigorous
                intellectual engagement with other bright students, and close
                attention from leading academics.
              </p>
              <p
                className="text-base leading-relaxed"
                style={{ color: "var(--text-secondary)" }}
              >
                Admission is competitive. Candidates are selected following
                careful consideration of a written application and an online
                interview. We typically receive six applications for each
                available place.
              </p>
            </div>
            <div className="text-center md:text-right">
              <div className="inline-block">
                <div
                  className="text-6xl md:text-7xl font-bold mb-2"
                  style={{
                    fontFamily: "var(--font-serif)",
                    color: "var(--accent-primary)",
                  }}
                >
                  6:1
                </div>
                <div
                  className="text-sm tracking-wider uppercase"
                  style={{ color: "var(--text-secondary)" }}
                >
                  Application Ratio
                </div>
                <div
                  className="text-xs mt-2"
                  style={{ color: "var(--text-secondary)", opacity: 0.5 }}
                >
                  Applications from 130 countries
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Testimonial */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.9 }}
          className="mt-16 text-center"
        >
          <blockquote
            className="text-lg md:text-xl italic max-w-3xl mx-auto mb-4"
            style={{
              fontFamily: "var(--font-serif)",
              color: "var(--text-primary)",
            }}
          >
            &ldquo;It made a huge difference to my confidence as well as my
            interest in the subject. I am a lot more confident in exploring
            political and economic ideas in my essays.&rdquo;
          </blockquote>
          <cite
            className="text-sm not-italic"
            style={{ color: "var(--text-secondary)" }}
          >
            — Ffion Gladwin, 2020
          </cite>
        </motion.div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ delay: 1 }}
          className="mt-12 text-center"
        >
          <a
            href="https://www.johnlockeinstitute.com/summer-school"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-magnetic"
          >
            <span>Explore All Programmes</span>
            <ArrowRight className="w-4 h-4 arrow" />
          </a>
        </motion.div>
      </div>
    </section>
  );
}