"use client";

import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { Radio, Calendar, MapPin } from "lucide-react";

const upcomingEvents = [
  {
    title: "Shortlist Notification",
    date: "7 Jul 2026",
    daysUntil: getDaysUntil("2026-07-07"),
    category: "competition",
    location: null,
  },
  {
    title: "Summer School — Cambridge",
    date: "6 Jul 2026",
    daysUntil: getDaysUntil("2026-07-06"),
    category: "course",
    location: "Cambridge, UK",
  },
  {
    title: "Academic Conference",
    date: "2–4 Oct 2026",
    daysUntil: getDaysUntil("2026-10-02"),
    category: "conference",
    location: "London",
  },
  {
    title: "Awards Dinner",
    date: "3 Oct 2026",
    daysUntil: getDaysUntil("2026-10-03"),
    category: "ceremony",
    location: "London",
  },
];

function getDaysUntil(dateStr: string): number {
  const target = new Date(dateStr);
  const now = new Date();
  const diff = target.getTime() - now.getTime();
  return Math.max(0, Math.ceil(diff / (1000 * 60 * 60 * 24)));
}

const categoryColors: Record<string, string> = {
  competition: "#3b82f6",
  course: "#10b981",
  conference: "#8b5cf6",
  ceremony: "#d4a853",
};

export default function LiveStatus() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  const nextEvent = upcomingEvents
    .filter((e) => e.daysUntil > 0)
    .sort((a, b) => a.daysUntil - b.daysUntil)[0];

  return (
    <section ref={ref} className="relative py-16 md:py-20 overflow-hidden">
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 gap-6">
          {/* Live Status Card */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            className="glass rounded-2xl p-6 md:p-8"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="flex items-center gap-2">
                <span className="relative flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500" />
                </span>
                <span
                  className="text-xs tracking-widest uppercase font-semibold"
                  style={{ color: "#10b981" }}
                >
                  Live Status
                </span>
              </div>
              <Radio
                className="w-3.5 h-3.5 animate-pulse"
                style={{ color: "#10b981" }}
              />
            </div>

            <h3
              className="text-xl md:text-2xl font-bold mb-3"
              style={{
                fontFamily: "var(--font-serif)",
                color: "var(--text-primary)",
              }}
            >
              Shortlist Review Period
            </h3>
            <p
              className="text-sm leading-relaxed mb-6"
              style={{ color: "var(--text-secondary)" }}
            >
              The judges are reviewing submissions from students in over 150
              countries. Shortlisted essayists will be notified by 7 July 2026.
            </p>

            {/* Status Steps */}
            <div className="flex items-center gap-2 text-xs">
              {[
                { label: "Registration", done: true },
                { label: "Submissions", done: true },
                { label: "Judging", done: false, active: true },
                { label: "Shortlist", done: false },
                { label: "Awards", done: false },
              ].map((step, i) => (
                <div key={step.label} className="flex items-center gap-2">
                  <div
                    className={`w-2 h-2 rounded-full ${
                      step.done
                        ? "bg-emerald-400"
                        : step.active
                        ? "bg-amber-400 animate-pulse"
                        : "bg-white/10"
                    }`}
                  />
                  <span
                    style={{
                      color: step.done
                        ? "#10b981"
                        : step.active
                        ? "#f59e0b"
                        : "var(--text-secondary)",
                      opacity: step.done || step.active ? 1 : 0.3,
                    }}
                  >
                    {step.label}
                  </span>
                  {i < 4 && (
                    <div
                      className="w-4 h-px"
                      style={{
                        background: step.done
                          ? "#10b981"
                          : "rgba(255,255,255,0.06)",
                      }}
                    />
                  )}
                </div>
              ))}
            </div>
          </motion.div>

          {/* Next Event Card */}
          {nextEvent && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ delay: 0.1 }}
              className="glass rounded-2xl p-6 md:p-8"
            >
              <div className="flex items-center gap-2 mb-6">
                <Calendar
                  className="w-4 h-4"
                  style={{ color: "var(--accent-primary)" }}
                />
                <span
                  className="text-xs tracking-widest uppercase font-semibold"
                  style={{ color: "var(--accent-primary)" }}
                >
                  Next Event
                </span>
              </div>

              <h3
                className="text-xl md:text-2xl font-bold mb-2"
                style={{
                  fontFamily: "var(--font-serif)",
                  color: "var(--text-primary)",
                }}
              >
                {nextEvent.title}
              </h3>

              {nextEvent.location && (
                <div
                  className="flex items-center gap-1.5 text-xs mb-4"
                  style={{ color: "var(--text-secondary)" }}
                >
                  <MapPin className="w-3 h-3" />
                  {nextEvent.location}
                </div>
              )}

              <div className="flex items-baseline gap-3 mb-6">
                <span
                  className="text-4xl md:text-5xl font-bold"
                  style={{
                    fontFamily: "var(--font-sans)",
                    color: "var(--text-primary)",
                  }}
                >
                  {nextEvent.daysUntil}
                </span>
                <span
                  className="text-sm tracking-wider uppercase"
                  style={{ color: "var(--text-secondary)" }}
                >
                  days remaining
                </span>
              </div>

              <div
                className="text-xs"
                style={{ color: "var(--text-secondary)", opacity: 0.5 }}
              >
                {nextEvent.date}
              </div>
            </motion.div>
          )}
        </div>

        {/* Upcoming Events Strip */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.2 }}
          className="mt-6 flex gap-4 overflow-x-auto pb-2 scrollbar-hide"
        >
          {upcomingEvents.map((event) => (
            <div
              key={event.title}
              className="glass rounded-xl px-4 py-3 shrink-0 flex items-center gap-3"
            >
              <div
                className="w-1.5 h-8 rounded-full"
                style={{
                  background: categoryColors[event.category] || "#3b82f6",
                }}
              />
              <div>
                <div
                  className="text-xs font-medium"
                  style={{ color: "var(--text-primary)" }}
                >
                  {event.title}
                </div>
                <div
                  className="text-[10px]"
                  style={{ color: "var(--text-secondary)", opacity: 0.5 }}
                >
                  {event.date}
                </div>
              </div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}