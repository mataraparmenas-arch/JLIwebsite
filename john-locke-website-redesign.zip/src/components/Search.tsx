"use client";

import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search as SearchIcon, X, ArrowRight } from "lucide-react";

const searchableItems = [
  { title: "Global Essay Prize", section: "Competition", href: "#essay-prize" },
  { title: "Economics Questions", section: "Essay Categories", href: "#essay-prize" },
  { title: "History Questions", section: "Essay Categories", href: "#essay-prize" },
  { title: "Philosophy Questions", section: "Essay Categories", href: "#essay-prize" },
  { title: "Politics Questions", section: "Essay Categories", href: "#essay-prize" },
  { title: "Law Questions", section: "Essay Categories", href: "#essay-prize" },
  { title: "Psychology Questions", section: "Essay Categories", href: "#essay-prize" },
  { title: "Theology Questions", section: "Essay Categories", href: "#essay-prize" },
  { title: "International Relations", section: "Essay Categories", href: "#essay-prize" },
  { title: "Public Policy", section: "Essay Categories", href: "#essay-prize" },
  { title: "Science & Technology", section: "Essay Categories", href: "#essay-prize" },
  { title: "Summer Schools", section: "Programmes", href: "#courses" },
  { title: "Oxford Programme", section: "Locations", href: "#courses" },
  { title: "Cambridge Programme", section: "Locations", href: "#courses" },
  { title: "Princeton Programme", section: "Locations", href: "#courses" },
  { title: "Singapore Programme", section: "Locations", href: "#courses" },
  { title: "Dubai Programme", section: "Locations", href: "#courses" },
  { title: "Hong Kong Programme", section: "Locations", href: "#courses" },
  { title: "Boston Programme", section: "Locations", href: "#courses" },
  { title: "Georgetown Programme", section: "Locations", href: "#courses" },
  { title: "Washington D.C. Programme", section: "Locations", href: "#courses" },
  { title: "Faculty & Guests", section: "People", href: "#faculty" },
  { title: "Professor Peter Millican", section: "Faculty", href: "#faculty" },
  { title: "Professor Jeffrey Miron", section: "Faculty", href: "#faculty" },
  { title: "Professor Terence Kealey", section: "Faculty", href: "#faculty" },
  { title: "Admissions", section: "Apply", href: "#courses" },
  { title: "About the Institute", section: "About", href: "#about" },
  { title: "John Locke", section: "About", href: "#about" },
  { title: "Contact", section: "Contact", href: "#contact" },
  { title: "Competition Timeline", section: "Competition", href: "#essay-prize" },
  { title: "Key Dates", section: "Competition", href: "#essay-prize" },
  { title: "Prizes & Scholarships", section: "Competition", href: "#essay-prize" },
  { title: "FAQ", section: "Competition", href: "#essay-prize" },
];

export default function SearchPalette() {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");

  const handleKey = useCallback(
    (e: KeyboardEvent) => {
      if (e.key === "/" && !open) {
        e.preventDefault();
        setOpen(true);
      }
      if (e.key === "Escape") setOpen(false);
    },
    [open]
  );

  useEffect(() => {
    window.addEventListener("keydown", handleKey);
    const handler = () => setOpen(true);
    window.addEventListener("toggle-search", handler as EventListener);
    return () => {
      window.removeEventListener("keydown", handleKey);
      window.removeEventListener("toggle-search", handler as EventListener);
    };
  }, [handleKey]);

  const results = query.length > 0
    ? searchableItems.filter(
        (item) =>
          item.title.toLowerCase().includes(query.toLowerCase()) ||
          item.section.toLowerCase().includes(query.toLowerCase())
      )
    : searchableItems.slice(0, 8);

  const handleSelect = (href: string) => {
    setOpen(false);
    setQuery("");
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-start justify-center pt-[20vh] px-4"
          style={{ background: "rgba(0,0,0,0.6)" }}
          onClick={() => setOpen(false)}
        >
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.98 }}
            className="w-full max-w-lg glass-strong rounded-2xl shadow-2xl overflow-hidden"
            style={{ background: "var(--bg-primary)" }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Search Input */}
            <div className="flex items-center gap-3 px-5 py-4 border-b border-white/5">
              <SearchIcon className="w-5 h-5 shrink-0" style={{ color: "var(--text-secondary)" }} />
              <input
                type="text"
                autoFocus
                placeholder="What are you looking for?"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="flex-1 bg-transparent outline-none text-base"
                style={{
                  color: "var(--text-primary)",
                  fontFamily: "var(--font-sans)",
                }}
              />
              <button
                onClick={() => setOpen(false)}
                className="shrink-0 w-7 h-7 rounded-md flex items-center justify-center hover:bg-white/5"
                style={{ color: "var(--text-secondary)" }}
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Results */}
            <div className="max-h-72 overflow-y-auto py-2">
              {results.length === 0 ? (
                <div
                  className="px-5 py-8 text-center text-sm"
                  style={{ color: "var(--text-secondary)" }}
                >
                  No results found for &ldquo;{query}&rdquo;
                </div>
              ) : (
                results.map((item, i) => (
                  <button
                    key={`${item.title}-${i}`}
                    onClick={() => handleSelect(item.href)}
                    className="w-full text-left px-5 py-3 flex items-center justify-between hover:bg-white/[0.03] transition-colors group"
                  >
                    <div>
                      <div
                        className="text-sm font-medium"
                        style={{ color: "var(--text-primary)" }}
                      >
                        {item.title}
                      </div>
                      <div
                        className="text-xs"
                        style={{ color: "var(--text-secondary)", opacity: 0.5 }}
                      >
                        {item.section}
                      </div>
                    </div>
                    <ArrowRight
                      className="w-3.5 h-3.5 opacity-0 group-hover:opacity-60 transition-opacity"
                      style={{ color: "var(--text-secondary)" }}
                    />
                  </button>
                ))
              )}
            </div>

            {/* Footer */}
            <div
              className="px-5 py-3 border-t border-white/5 flex items-center justify-between text-xs"
              style={{ color: "var(--text-secondary)", opacity: 0.4 }}
            >
              <span>Press ESC to close</span>
              <span>↵ to select</span>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}