"use client";

import { useRef, useState, useEffect } from "react";
import { motion, useInView } from "framer-motion";
import { MapPin } from "lucide-react";

const stats = [
  { value: 100, suffix: "+", label: "Countries Represented" },
  { value: 150, suffix: "+", label: "Countries Submitting Essays" },
  { value: 130, suffix: "", label: "Countries Applying for Courses" },
  { value: 9, suffix: "", label: "Global Locations" },
];

function AnimatedCounter({
  target,
  suffix,
  isInView,
  delay,
}: {
  target: number;
  suffix: string;
  isInView: boolean;
  delay: number;
}) {
  const [count, setCount] = useState(0);
  const hasAnimated = useRef(false);

  useEffect(() => {
    if (!isInView || hasAnimated.current) return;
    hasAnimated.current = true;
    const timer = setTimeout(() => {
      let start = 0;
      const duration = 2000;
      const step = (timestamp: number) => {
        if (!start) start = timestamp;
        const progress = Math.min((timestamp - start) / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3);
        setCount(Math.floor(eased * target));
        if (progress < 1) requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
    }, delay * 1000);
    return () => clearTimeout(timer);
  }, [isInView, target, delay]);

  return (
    <div
      className="text-4xl md:text-5xl lg:text-6xl font-bold"
      style={{
        fontFamily: "var(--font-sans)",
        color: "var(--text-primary)",
      }}
    >
      {count}
      {suffix}
    </div>
  );
}

const mapLocations = [
  { name: "Oxford", x: 47, y: 28 },
  { name: "Cambridge", x: 48.5, y: 25.5 },
  { name: "Princeton", x: 24, y: 34 },
  { name: "Boston", x: 25.5, y: 27 },
  { name: "Georgetown", x: 23, y: 37 },
  { name: "Singapore", x: 74, y: 57 },
  { name: "Hong Kong", x: 76, y: 38 },
  { name: "Dubai", x: 60, y: 40 },
  { name: "Washington D.C.", x: 22, y: 35 },
];

const connections = [
  [0, 2], [0, 7], [1, 6], [2, 3], [4, 8], [5, 6], [7, 6], [0, 5],
];

export default function GlobalReach() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section
      id="global"
      ref={ref}
      className="relative py-24 md:py-32 overflow-hidden"
    >
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Label */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          className="mb-4 text-center"
        >
          <span
            className="text-xs tracking-[0.3em] uppercase font-medium"
            style={{ color: "var(--accent-primary)" }}
          >
            Global Community
          </span>
        </motion.div>

        {/* Heading */}
        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.1 }}
          className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6 text-center"
          style={{ fontFamily: "var(--font-serif)" }}
        >
          A Truly <span className="text-gradient-blue">Global</span> Institution
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.2 }}
          className="max-w-2xl mx-auto text-base md:text-lg leading-relaxed mb-16 text-center"
          style={{ color: "var(--text-secondary)" }}
        >
          The John Locke Institute brings together students and faculty from every
          continent, creating a truly international intellectual community.
        </motion.p>

        {/* Animated Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8 mb-16">
          {stats.map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.3 + i * 0.1 }}
              className="text-center"
            >
              <AnimatedCounter
                target={stat.value}
                suffix={stat.suffix}
                isInView={isInView}
                delay={0.4 + i * 0.15}
              />
              <div
                className="text-sm mt-2 tracking-wide"
                style={{ color: "var(--text-secondary)", opacity: 0.7 }}
              >
                {stat.label}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Map Visualization */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.6 }}
          className="glass rounded-2xl p-6 md:p-10 relative overflow-hidden"
        >
          <div className="relative" style={{ paddingBottom: "50%" }}>
            {/* Background map shape */}
            <div className="absolute inset-0 opacity-[0.03]">
              <svg viewBox="0 0 1000 500" className="w-full h-full" fill="currentColor">
                <path d="M120,100 Q180,80 240,95 Q300,110 340,140 Q360,170 350,210 Q340,250 310,270 Q280,290 250,280 Q220,270 190,240 Q160,210 140,170 Z" />
                <path d="M430,80 Q490,60 550,75 Q610,90 660,120 Q710,150 730,190 Q750,230 720,260 Q690,290 650,280 Q610,270 570,240 Q530,210 490,170 Q460,130 430,80 Z" />
                <path d="M480,270 Q530,250 590,260 Q650,270 690,300 Q720,330 710,360 Q700,390 670,400 Q640,410 600,390 Q560,370 530,330 Q510,290 480,270 Z" />
                <path d="M740,130 Q790,110 850,125 Q910,140 940,170 Q960,200 950,240 Q940,280 900,290 Q860,300 820,280 Q780,260 750,220 Q735,170 740,130 Z" />
              </svg>
            </div>

            {/* Connection Lines */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none z-10">
              {connections.map(([from, to], i) => (
                <motion.line
                  key={i}
                  x1={`${mapLocations[from].x}%`}
                  y1={`${mapLocations[from].y}%`}
                  x2={`${mapLocations[to].x}%`}
                  y2={`${mapLocations[to].y}%`}
                  stroke="rgba(59, 130, 246, 0.08)"
                  strokeWidth="1"
                  strokeDasharray="4 4"
                  initial={{ pathLength: 0, opacity: 0 }}
                  animate={isInView ? { pathLength: 1, opacity: 1 } : {}}
                  transition={{ delay: 1 + i * 0.1, duration: 1.5 }}
                />
              ))}
            </svg>

            {/* Location Points */}
            {mapLocations.map((loc, i) => (
              <motion.div
                key={loc.name}
                initial={{ opacity: 0, scale: 0 }}
                animate={isInView ? { opacity: 1, scale: 1 } : {}}
                transition={{ delay: 0.8 + i * 0.1, type: "spring", stiffness: 200 }}
                className="absolute z-20 group"
                style={{ left: `${loc.x}%`, top: `${loc.y}%` }}
              >
                {/* Pulse */}
                <div className="absolute -translate-x-1/2 -translate-y-1/2 w-8 h-8">
                  <div className="w-full h-full rounded-full border border-blue-400/20 animate-ping" />
                </div>

                {/* Dot */}
                <div className="absolute -translate-x-1/2 -translate-y-1/2 w-2.5 h-2.5 rounded-full bg-blue-400 shadow-lg shadow-blue-400/30 group-hover:scale-150 transition-transform cursor-pointer" />

                {/* Tooltip */}
                <div className="absolute left-4 -translate-y-1/2 whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-30">
                  <div className="glass-strong rounded-lg px-3 py-1.5 flex items-center gap-2 shadow-lg">
                    <MapPin className="w-3 h-3 text-blue-400" />
                    <span className="text-xs font-medium" style={{ color: "var(--text-primary)" }}>
                      {loc.name}
                    </span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}