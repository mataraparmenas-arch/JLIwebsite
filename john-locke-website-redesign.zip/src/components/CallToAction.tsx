"use client";

import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { ArrowRight, Sparkles } from "lucide-react";

export default function CallToAction() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="relative py-24 md:py-32 overflow-hidden">
      {/* Background Effect */}
      <div className="absolute inset-0">
        <div
          className="absolute inset-0"
          style={{
            background:
              "radial-gradient(ellipse at 50% 50%, rgba(59, 130, 246, 0.08) 0%, transparent 70%)",
          }}
        />
        <div
          className="absolute inset-0"
          style={{
            background:
              "radial-gradient(ellipse at 30% 60%, rgba(139, 92, 246, 0.05) 0%, transparent 60%)",
          }}
        />
      </div>

      <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        {/* Large atmospheric text */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={isInView ? { opacity: 1, scale: 1 } : {}}
          transition={{ duration: 1 }}
          className="mb-8"
        >
          <span
            className="text-6xl sm:text-7xl md:text-8xl lg:text-9xl font-bold tracking-tighter leading-none"
            style={{
              fontFamily: "var(--font-serif)",
              background:
                "linear-gradient(180deg, var(--text-primary) 0%, rgba(148, 163, 184, 0.3) 100%)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
            }}
          >
            WILL YOU
          </span>
          <br />
          <span
            className="text-6xl sm:text-7xl md:text-8xl lg:text-9xl font-bold tracking-tighter leading-none text-gradient-blue"
            style={{ fontFamily: "var(--font-serif)" }}
          >
            JOIN US?
          </span>
        </motion.div>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.3 }}
          className="text-base md:text-lg max-w-2xl mx-auto mb-12"
          style={{ color: "var(--text-secondary)" }}
        >
          Compete with students from over one hundred countries for prizes in
          philosophy, politics, economics, history, psychology, theology and law.
          Entry is free.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.5 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <a
            href="https://www.johnlockeinstitute.com/essay-competition"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary !text-base !px-10 !py-5"
          >
            <Sparkles className="w-5 h-5" />
            Enter the Essay Prize
            <ArrowRight className="w-5 h-5" />
          </a>
          <a
            href="https://www.johnlockeinstitute.com/summer-school"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-gold !text-base !px-10 !py-5"
          >
            <span>Apply for Summer School</span>
            <ArrowRight className="w-4 h-4" />
          </a>
        </motion.div>

        {/* Decorative elements */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 0.3 } : {}}
          transition={{ delay: 0.8 }}
          className="mt-16 flex items-center justify-center gap-8"
        >
          {["Oxford", "Cambridge", "Princeton", "Singapore", "Dubai"].map(
            (place, i) => (
              <motion.span
                key={place}
                initial={{ opacity: 0 }}
                animate={isInView ? { opacity: 0.3 } : {}}
                transition={{ delay: 0.9 + i * 0.1 }}
                className="text-xs tracking-widest uppercase hidden sm:block"
                style={{ color: "var(--text-secondary)" }}
              >
                {place}
              </motion.span>
            )
          )}
        </motion.div>
      </div>
    </section>
  );
}