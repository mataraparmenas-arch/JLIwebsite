"use client";

import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { BookOpen, Lightbulb, Users, GraduationCap } from "lucide-react";

const pillars = [
  {
    icon: BookOpen,
    title: "Independent Thought",
    description:
      "We seek to nurture intellectual skills and help our students cultivate habits of mind to make you a better philosopher, political scientist, economist, legal scholar, or historian.",
  },
  {
    icon: Lightbulb,
    title: "Critical Analysis",
    description:
      "We are less concerned with communicating information and more interested in helping people learn how to doubt, question, and challenge, how to reason logically.",
  },
  {
    icon: Users,
    title: "Global Community",
    description:
      "We bring together the very best students from all over the world and invite inspiring professors to challenge them to listen generously, to think critically.",
  },
  {
    icon: GraduationCap,
    title: "Academic Ambition",
    description:
      "Past students have gone on to study at Oxford, Cambridge, Princeton, Harvard, Yale, Stanford, Chicago, and Berkeley. We strive to make learning stimulating, rewarding, and fun.",
  },
];

export default function About() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section
      id="about"
      ref={ref}
      className="relative py-24 md:py-32 overflow-hidden"
    >
      {/* Background */}
      <div className="absolute inset-0 gradient-mesh" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Label */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6 }}
          className="mb-4"
        >
          <span
            className="text-xs tracking-[0.3em] uppercase font-medium"
            style={{ color: "var(--accent-primary)" }}
          >
            Our Vision
          </span>
        </motion.div>

        {/* Heading */}
        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.1 }}
          className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6"
          style={{ fontFamily: "var(--font-serif)" }}
        >
          An independent educational
          <br />
          <span className="text-gradient-blue">
            organisation that works to embolden
          </span>
          <br />
          the best and brightest students.
        </motion.h2>

        {/* Description */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="max-w-3xl text-base md:text-lg leading-relaxed mb-16"
          style={{ color: "var(--text-secondary)" }}
        >
          Through our various programmes — residential courses, revision
          seminars, essay competitions, and special events — we inspire
          students to aim high and we equip them with the skills they need
          in order to achieve their goals.
        </motion.p>

        {/* Who was John Locke */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="glass rounded-2xl p-8 md:p-12 mb-16 relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-bl from-blue-500/5 to-transparent rounded-full -translate-y-1/2 translate-x-1/2" />
          <div className="relative">
            <h3
              className="text-2xl md:text-3xl font-bold mb-6"
              style={{ fontFamily: "var(--font-serif)" }}
            >
              Who was{" "}
              <span className="text-gradient-gold italic">John Locke?</span>
            </h3>
            <div className="grid md:grid-cols-2 gap-8">
              <p
                className="text-base leading-relaxed"
                style={{ color: "var(--text-secondary)" }}
              >
                The Institute is named in honour of the eminent seventeenth
                century Oxford philosopher, John Locke. As influential in the
                United States as in his native England, John Locke was the
                grandfather of Classical Liberalism. The very ideal of the
                Renaissance Man, Locke was a philosopher, political scientist,
                economist and medical doctor; he was a man of ideas and a man of
                action.
              </p>
              <blockquote
                className="border-l-2 pl-6 italic text-base md:text-lg"
                style={{
                  borderColor: "var(--accent-tertiary)",
                  color: "var(--text-secondary)",
                  fontFamily: "var(--font-serif)",
                }}
              >
                &ldquo;A teacher should remember that his business is not so much
                to teach all that is knowable, as to raise in the student a love
                and esteem of knowledge; and to put him in the right way of
                knowing and improving himself.&rdquo;
              </blockquote>
            </div>
          </div>
        </motion.div>

        {/* Pillars */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {pillars.map((pillar, i) => (
            <motion.div
              key={pillar.title}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.4 + i * 0.1 }}
              className="card-premium glass rounded-xl p-6 group"
            >
              <div className="w-12 h-12 rounded-lg flex items-center justify-center mb-5 bg-gradient-to-br from-blue-500/10 to-violet-500/10 group-hover:from-blue-500/20 group-hover:to-violet-500/20 transition-all duration-500">
                <pillar.icon
                  className="w-5 h-5"
                  style={{ color: "var(--accent-primary)" }}
                />
              </div>
              <h4
                className="text-lg font-semibold mb-3"
                style={{ fontFamily: "var(--font-serif)" }}
              >
                {pillar.title}
              </h4>
              <p
                className="text-sm leading-relaxed"
                style={{ color: "var(--text-secondary)" }}
              >
                {pillar.description}
              </p>
            </motion.div>
          ))}
        </div>

        {/* Think Rethink Section */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 1, delay: 0.8 }}
          className="mt-24 text-center"
        >
          <div className="flex flex-wrap items-center justify-center gap-4 md:gap-8 mb-8">
            {["THINK.", "QUESTION.", "LISTEN.", "REASON.", "ARGUE.", "RETHINK."].map(
              (word, i) => (
                <motion.span
                  key={word}
                  initial={{ opacity: 0, y: 20 }}
                  animate={isInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.5, delay: 0.9 + i * 0.1 }}
                  className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight"
                  style={{
                    fontFamily: "var(--font-serif)",
                    color:
                      i === 0 || i === 5
                        ? "var(--accent-primary)"
                        : "var(--text-primary)",
                    opacity: i === 0 || i === 5 ? 1 : 0.3,
                  }}
                >
                  {word}
                </motion.span>
              )
            )}
          </div>
          <p
            className="text-base md:text-lg max-w-2xl mx-auto"
            style={{ color: "var(--text-secondary)" }}
          >
            We bring together the very best students from all over the world and
            invite inspiring professors to challenge them to listen generously,
            to think critically, and to develop and deliver robust responses with
            clarity, precision and persuasive force.
          </p>
        </motion.div>
      </div>
    </section>
  );
}