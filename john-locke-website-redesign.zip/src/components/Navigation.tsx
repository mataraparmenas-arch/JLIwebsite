"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Menu,
  X,
  ChevronDown,
  Search,
  Sun,
  Moon,
} from "lucide-react";

const navLinks = [
  { label: "About", href: "#about" },
  {
    label: "Programmes",
    href: "#courses",
    children: [
      { label: "Summer Schools", href: "#courses" },
      { label: "Gap Year", href: "#courses" },
    ],
  },
  { label: "Essay Prize", href: "#essay-prize" },
  { label: "Faculty", href: "#faculty" },
  { label: "Contact", href: "#contact" },
];

export default function Navigation() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const [theme, setTheme] = useState<"dark" | "light">("dark");

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    const saved = localStorage.getItem("theme") as "dark" | "light" | null;
    if (saved) setTheme(saved);
  }, []);

  const toggleTheme = () => {
    const next = theme === "dark" ? "light" : "dark";
    setTheme(next);
    document.documentElement.setAttribute("data-theme", next);
    localStorage.setItem("theme", next);
  };

  const handleNavClick = (href: string) => {
    setMobileOpen(false);
    const el = document.querySelector(href);
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <>
      {/* Scroll Progress */}
      <ScrollProgress />

      {/* Main Nav */}
      <motion.nav
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.6, ease: [0.4, 0, 0.2, 1] }}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          scrolled
            ? "glass-strong shadow-lg shadow-black/10"
            : "bg-transparent"
        }`}
        style={{ backdropFilter: scrolled ? "blur(20px)" : "none" }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 md:h-20">
            {/* Logo */}
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                window.scrollTo({ top: 0, behavior: "smooth" });
              }}
              className="flex items-center gap-3 group"
            >
              <div className="w-8 h-8 md:w-9 md:h-9 rounded-lg flex items-center justify-center bg-gradient-to-br from-blue-500 to-violet-600 shadow-lg shadow-blue-500/20">
                <span
                  className="text-white font-bold text-sm md:text-base"
                  style={{ fontFamily: "var(--font-serif)" }}
                >
                  J
                </span>
              </div>
              <div className="flex flex-col">
                <span
                  className="text-sm md:text-base font-semibold tracking-wide"
                  style={{ color: "var(--text-primary)" }}
                >
                  JOHN LOCKE
                </span>
                <span
                  className="text-[10px] md:text-xs tracking-[0.2em] uppercase"
                  style={{ color: "var(--text-secondary)", opacity: 0.6 }}
                >
                  Institute
                </span>
              </div>
            </a>

            {/* Desktop Nav */}
            <div className="hidden lg:flex items-center gap-1">
              {navLinks.map((link) => (
                <div
                  key={link.label}
                  className="relative"
                  onMouseEnter={() =>
                    link.children && setActiveDropdown(link.label)
                  }
                  onMouseLeave={() => setActiveDropdown(null)}
                >
                  <button
                    onClick={() => handleNavClick(link.href)}
                    className="px-4 py-2 text-sm font-medium tracking-wide transition-colors duration-300 flex items-center gap-1 rounded-md hover:bg-white/5"
                    style={{ color: "var(--text-secondary)" }}
                  >
                    {link.label}
                    {link.children && (
                      <ChevronDown className="w-3 h-3 opacity-50" />
                    )}
                  </button>

                  {/* Dropdown */}
                  {link.children && activeDropdown === link.label && (
                    <motion.div
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 8 }}
                      className="absolute top-full left-0 mt-1 py-2 w-48 glass-strong rounded-xl shadow-xl"
                    >
                      {link.children.map((child) => (
                        <button
                          key={child.label}
                          onClick={() => handleNavClick(child.href)}
                          className="w-full text-left px-4 py-2.5 text-sm hover:bg-white/5 transition-colors"
                          style={{ color: "var(--text-secondary)" }}
                        >
                          {child.label}
                        </button>
                      ))}
                    </motion.div>
                  )}
                </div>
              ))}
            </div>

            {/* Right Actions */}
            <div className="flex items-center gap-2 md:gap-3">
              {/* Search */}
              <button
                onClick={() => {
                  const event = new CustomEvent("toggle-search");
                  window.dispatchEvent(event);
                }}
                className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm transition-all hover:bg-white/5"
                style={{
                  color: "var(--text-secondary)",
                  border: "1px solid rgba(255,255,255,0.06)",
                }}
              >
                <Search className="w-3.5 h-3.5" />
                <span className="opacity-60">Search</span>
                <kbd className="text-[10px] px-1.5 py-0.5 rounded bg-white/5 opacity-40">
                  /
                </kbd>
              </button>

              {/* Theme Toggle */}
              <button
                onClick={toggleTheme}
                className="w-9 h-9 rounded-lg flex items-center justify-center transition-all hover:bg-white/5"
                style={{ color: "var(--text-secondary)" }}
                aria-label="Toggle theme"
              >
                {theme === "dark" ? (
                  <Sun className="w-4 h-4" />
                ) : (
                  <Moon className="w-4 h-4" />
                )}
              </button>

              {/* CTA */}
              <a
                href="https://www.johnlockeinstitute.com/essay-competition"
                target="_blank"
                rel="noopener noreferrer"
                className="hidden md:inline-flex btn-magnetic !py-2 !px-5 !text-xs"
              >
                <span>Apply Now</span>
              </a>

              {/* Mobile Toggle */}
              <button
                onClick={() => setMobileOpen(!mobileOpen)}
                className="lg:hidden w-10 h-10 rounded-lg flex items-center justify-center hover:bg-white/5 transition-colors"
                style={{ color: "var(--text-primary)" }}
                aria-label="Toggle menu"
              >
                {mobileOpen ? (
                  <X className="w-5 h-5" />
                ) : (
                  <Menu className="w-5 h-5" />
                )}
              </button>
            </div>
          </div>
        </div>
      </motion.nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-40 lg:hidden"
            style={{ background: "var(--bg-primary)" }}
          >
            <div className="flex flex-col items-center justify-center h-full gap-8 px-8">
              {navLinks.map((link, i) => (
                <motion.button
                  key={link.label}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.08 }}
                  onClick={() => handleNavClick(link.href)}
                  className="text-3xl font-light tracking-wide"
                  style={{
                    fontFamily: "var(--font-serif)",
                    color: "var(--text-primary)",
                  }}
                >
                  {link.label}
                </motion.button>
              ))}

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.4 }}
                className="mt-8"
              >
                <a
                  href="https://www.johnlockeinstitute.com/essay-competition"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-primary !text-base !px-10 !py-4"
                >
                  Apply Now
                </a>
              </motion.div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

function ScrollProgress() {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const scrollTop = window.scrollY;
      const docHeight =
        document.documentElement.scrollHeight - window.innerHeight;
      setProgress(docHeight > 0 ? (scrollTop / docHeight) * 100 : 0);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div
      className="scroll-progress"
      style={{ width: `${progress}%` }}
      role="progressbar"
      aria-valuenow={Math.round(progress)}
      aria-valuemin={0}
      aria-valuemax={100}
    />
  );
}