"use client";

import { useRef, useState } from "react";
import { motion, useInView, AnimatePresence } from "framer-motion";
import { ExternalLink, X } from "lucide-react";

const faculty = [
  {
    name: "Professor Peter Millican",
    institution: "Hertford College, University of Oxford",
    title: "Gilbert Ryle Fellow & Professor of Philosophy",
    bio: "Professor Millican has a special interest in the relationship between Philosophy and Computer Science and the ethics of artificial intelligence. He created the Philosophy & Computer Science degree at the University of Oxford. A noted Hume scholar, Prof Millican is also a Chess Grandmaster.",
    category: "Philosophy",
    wiki: "https://en.wikipedia.org/wiki/Peter_Millican",
  },
  {
    name: "Dr. John Filling",
    institution: "King's College, University of Cambridge",
    title: "Lecturer in Philosophy",
    bio: "Dr Filling is a lecturer in the faculty of philosophy at the University of Cambridge, and a fellow and director of studies in philosophy at King's College, Cambridge. After an undergraduate degree in Philosophy, Politics and Economics, Dr Filling was awarded an M.Phil. and then a D.Phil., all from Corpus Christi College, University of Oxford.",
    category: "Philosophy",
  },
  {
    name: "Professor Jeffrey Miron",
    institution: "Harvard University",
    title: "Director of Undergraduate Studies, Economics",
    bio: "Professor Miron is Director of Undergraduate Studies in the Department of Economics at Harvard University. He is the author of four books including Drug War Crimes: The Consequences of Prohibition.",
    category: "Economics",
    wiki: "https://en.wikipedia.org/wiki/Jeffrey_Miron",
  },
  {
    name: "Professor Terence Kealey",
    institution: "Author",
    title: "Chairman of Examiners",
    bio: "Professor Kealey is a historian of science and economics. Originally a biochemist at Balliol College, Oxford, and later at the University of Cambridge, Professor Kealey was Vice-Chancellor of the University of Buckingham. He is the author of The Economic Laws of Scientific Research.",
    category: "History",
    wiki: "https://en.wikipedia.org/wiki/Terence_Kealey",
  },
  {
    name: "Lord Hannan of Kingsclere",
    institution: "House of Lords",
    title: "Member of the House of Lords",
    bio: "Lord Hannan is a Member of the House of Lords and Vice-Chairman of the UK Conservative Party. A Member of the UK Board of Trade and President of the Initiative for Free Trade. Born in Lima, Peru, Lord Hannan is fluent in French and Spanish. He holds a First Class honours degree in Modern History from Oriel College, University of Oxford.",
    category: "Politics",
    wiki: "https://en.wikipedia.org/wiki/Daniel_Hannan",
  },
  {
    name: "Professor Omar Wasow",
    institution: "UC Berkeley",
    title: "Assistant Professor, Political Science",
    bio: "Professor Wasow is Assistant Professor in the Department of Political Science at UC Berkeley. He was a statistician and Assistant Professor of Politics at Princeton University. He holds a BA from Stanford and an MA in Government, an MA in Statistics, and a PhD in African American Studies, all from Harvard University.",
    category: "Politics",
    wiki: "https://en.wikipedia.org/wiki/Omar_Wasow",
  },
  {
    name: "Dr. Helen Dale",
    institution: "Author, Lawyer and Historian",
    title: "Miles Franklin Award Winner",
    bio: "Helen Dale became the youngest winner of Australia's premier literary prize, the Miles Franklin Award. She read law at Brasenose College, Oxford. Her latest book, Kingdom of the Wicked, imagines a post-industrial Roman Empire.",
    category: "Law",
    wiki: "https://en.wikipedia.org/wiki/Helen_Dale",
  },
  {
    name: "Professor Ralf Bader",
    institution: "Université de Fribourg",
    title: "Professor of Philosophy",
    bio: "Professor Bader is professor of Philosophy at the Université de Fribourg in Switzerland, and Chairman of the Department of Ethics and Politics Philosophy. His research focuses on ethics, meta-ethics, metaphysics, Kant, political philosophy and decision theory. Previously he was a Fellow of Merton College, Oxford.",
    category: "Philosophy",
  },
  {
    name: "Dr. Tom Palmer",
    institution: "Atlas Network",
    title: "Chairman of the Board of Fellows",
    bio: "Dr Palmer is Chairman of the Board of Fellows at the John Locke Institute, Executive Vice President for International Programmes at the Atlas Network, and Senior Fellow at the Cato Institute. He has a D.Phil. in Politics from Hertford College, University of Oxford.",
    category: "Politics",
    wiki: "https://en.wikipedia.org/wiki/Tom_G._Palmer",
  },
  {
    name: "Professor Bryan Caplan",
    institution: "George Mason University",
    title: "Professor of Economics",
    bio: "Professor Caplan is a professor of economics at George Mason University, a research fellow at the Mercatus Center, and an adjunct scholar at the Cato Institute. He is a self-described 'economic libertarian'.",
    category: "Economics",
    wiki: "https://en.wikipedia.org/wiki/Bryan_Caplan",
  },
  {
    name: "Professor Alan Ryan FBA",
    institution: "University of Oxford",
    title: "Former Warden of New College",
    bio: "Professor Ryan was Warden of New College, Oxford, professor of politics at Princeton University and professor of philosophy at Stanford. He is the author of eleven books, including the authoritative On Politics.",
    category: "Politics",
    wiki: "https://en.wikipedia.org/wiki/Alan_Ryan",
  },
  {
    name: "Dr. Stephen Davies",
    institution: "John Locke Institute",
    title: "Distinguished Fellow in History",
    bio: "Dr Davies is Distinguished Fellow in History at the John Locke Institute. He is the author of Empiricism and History, The Economics and Politics of Brexit, and The Wealth Explosion: the Nature and Origins of Modernity.",
    category: "History",
  },
];

const categoryColors: Record<string, string> = {
  Philosophy: "#ec4899",
  Economics: "#10b981",
  Politics: "#ef4444",
  History: "#f59e0b",
  Law: "#8b5cf6",
  Psychology: "#06b6d4",
};

export default function Faculty() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [selected, setSelected] = useState<number | null>(null);

  return (
    <section
      id="faculty"
      ref={ref}
      className="relative py-24 md:py-32 overflow-hidden"
    >
      <div className="absolute inset-0">
        <div
          className="absolute top-1/4 right-0 w-[500px] h-[500px] rounded-full"
          style={{
            background:
              "radial-gradient(circle, rgba(139, 92, 246, 0.04) 0%, transparent 70%)",
          }}
        />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Label */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          className="mb-4"
        >
          <span
            className="text-xs tracking-[0.3em] uppercase font-medium"
            style={{ color: "var(--accent-secondary)" }}
          >
            Faculty & Guests
          </span>
        </motion.div>

        {/* Heading */}
        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.1 }}
          className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-4"
          style={{ fontFamily: "var(--font-serif)" }}
        >
          A Global Network of
          <br />
          <span className="text-gradient-blue">Inspiring Scholars</span>
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.2 }}
          className="max-w-3xl text-base md:text-lg leading-relaxed mb-16"
          style={{ color: "var(--text-secondary)" }}
        >
          Most of our professors and preceptors come from Oxford or Cambridge, or
          leading US universities. They are all brilliant, and some of them have
          a global reputation; you will notice that they love ideas and they
          love to challenge and inspire bright, curious students.
        </motion.p>

        {/* Faculty Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
          {faculty.map((f, i) => (
            <motion.div
              key={f.name}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.3 + i * 0.05 }}
              onClick={() => setSelected(i)}
              className="card-premium glass rounded-xl p-6 group cursor-pointer relative overflow-hidden"
            >
              {/* Category Badge */}
              <div
                className="absolute top-4 right-4 w-2 h-2 rounded-full"
                style={{ background: categoryColors[f.category] || "#3b82f6" }}
              />

              {/* Avatar placeholder */}
              <div className="w-14 h-14 rounded-full mb-4 flex items-center justify-center bg-gradient-to-br from-blue-500/10 to-violet-500/10">
                <span
                  className="text-lg font-bold"
                  style={{
                    fontFamily: "var(--font-serif)",
                    color: "var(--accent-primary)",
                  }}
                >
                  {f.name
                    .replace(/^(Professor|Dr\.?|Lord|Mr)\s+/i, "")
                    .charAt(0)}
                </span>
              </div>

              <h4
                className="text-base font-semibold mb-1 group-hover:text-blue-400 transition-colors"
                style={{ color: "var(--text-primary)" }}
              >
                {f.name}
              </h4>
              <p
                className="text-xs mb-1"
                style={{ color: "var(--accent-primary)" }}
              >
                {f.institution}
              </p>
              <p
                className="text-xs mb-3"
                style={{
                  color: "var(--text-secondary)",
                  opacity: 0.6,
                }}
              >
                {f.title}
              </p>
              <p
                className="text-sm leading-relaxed line-clamp-3"
                style={{ color: "var(--text-secondary)" }}
              >
                {f.bio}
              </p>
            </motion.div>
          ))}
        </div>

        {/* Student Testimonials */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.8 }}
          className="mt-16"
        >
          <h3
            className="text-xl md:text-2xl font-bold mb-8 text-center"
            style={{ fontFamily: "var(--font-serif)" }}
          >
            What Students Say
          </h3>

          <div className="grid sm:grid-cols-2 gap-6">
            {[
              {
                quote:
                  "An excellent teacher, David Friedman helps fully develop your intellectual capabilities. He cares a great deal about his students.",
                author: "Capri Mancini",
              },
              {
                quote:
                  "Dr. Filling has changed how I view relationships among people, governments, and other entities.",
                author: "Sean Sinanan",
              },
              {
                quote:
                  "Robin Hanson, one of the most interesting professors I have ever met, challenged my beliefs during precepts and at dinner.",
                author: "Charlotte Baxendale",
              },
              {
                quote:
                  "It was an honour to be taught by Alan Ryan; he was extremely helpful on the Oxbridge admissions process.",
                author: "Alison Liu",
              },
            ].map((t, i) => (
              <div key={i} className="glass rounded-xl p-6">
                <blockquote
                  className="text-sm leading-relaxed mb-4 italic"
                  style={{
                    fontFamily: "var(--font-serif)",
                    color: "var(--text-secondary)",
                  }}
                >
                  &ldquo;{t.quote}&rdquo;
                </blockquote>
                <cite
                  className="text-xs not-italic font-medium"
                  style={{ color: "var(--accent-primary)" }}
                >
                  — {t.author}
                </cite>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Faculty Detail Modal */}
      <AnimatePresence>
        {selected !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
            style={{ background: "rgba(0,0,0,0.7)" }}
            onClick={() => setSelected(null)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="glass-strong rounded-2xl p-8 max-w-lg w-full relative"
              style={{ background: "var(--bg-primary)" }}
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={() => setSelected(null)}
                className="absolute top-4 right-4 w-8 h-8 rounded-lg flex items-center justify-center hover:bg-white/5 transition-colors"
                style={{ color: "var(--text-secondary)" }}
              >
                <X className="w-4 h-4" />
              </button>

              <div
                className="w-16 h-16 rounded-full mb-5 flex items-center justify-center bg-gradient-to-br from-blue-500/10 to-violet-500/10"
              >
                <span
                  className="text-2xl font-bold"
                  style={{
                    fontFamily: "var(--font-serif)",
                    color: "var(--accent-primary)",
                  }}
                >
                  {faculty[selected].name
                    .replace(/^(Professor|Dr\.?|Lord|Mr)\s+/i, "")
                    .charAt(0)}
                </span>
              </div>

              <div
                className="inline-block px-2 py-0.5 rounded text-xs mb-3"
                style={{
                  background: `${
                    categoryColors[faculty[selected].category] || "#3b82f6"
                  }20`,
                  color:
                    categoryColors[faculty[selected].category] || "#3b82f6",
                }}
              >
                {faculty[selected].category}
              </div>

              <h3
                className="text-xl font-bold mb-1"
                style={{
                  fontFamily: "var(--font-serif)",
                  color: "var(--text-primary)",
                }}
              >
                {faculty[selected].name}
              </h3>
              <p
                className="text-sm mb-1"
                style={{ color: "var(--accent-primary)" }}
              >
                {faculty[selected].institution}
              </p>
              <p
                className="text-xs mb-5"
                style={{ color: "var(--text-secondary)", opacity: 0.6 }}
              >
                {faculty[selected].title}
              </p>
              <p
                className="text-sm leading-relaxed mb-5"
                style={{ color: "var(--text-secondary)" }}
              >
                {faculty[selected].bio}
              </p>

              {faculty[selected].wiki && (
                <a
                  href={faculty[selected].wiki}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-xs"
                  style={{ color: "var(--accent-primary)" }}
                >
                  <ExternalLink className="w-3 h-3" />
                  Wikipedia
                </a>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}